/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3_10116075_latihan59_detektifconan;

/**
 *
 *  Nama : DESIS FIRMANSYAH
* Kelas : IF3
* NIM   : 10116075
* Deskripsi Program : program ini berisi program untuk menampilkan tokoh tokoh
* dan peran dalam film Detektif Conan
 */
public class Tokoh {
    protected String nama;
    protected String peran;

    public Tokoh(String nama, String peran) {
        this.nama = nama;
        this.peran = peran;
    }
    
   
}
