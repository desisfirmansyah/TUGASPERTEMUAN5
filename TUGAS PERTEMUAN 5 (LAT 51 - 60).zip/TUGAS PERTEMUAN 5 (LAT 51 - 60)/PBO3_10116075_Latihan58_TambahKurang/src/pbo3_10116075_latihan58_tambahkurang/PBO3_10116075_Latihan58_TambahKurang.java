/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3_10116075_latihan58_tambahkurang;

/**
 *
 *  Nama : DESIS FIRMANSYAH
* Kelas : IF3
* NIM   : 10116075
* Deskripsi Program : program ini berisi program untuk menampilkan hasil 
* penjumlahan dan hasil selisih dengan inputan yg sudah ditentukan dengan konsep
* inheritance
 */
public class PBO3_10116075_Latihan58_TambahKurang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JumlahBilangan jb = new JumlahBilangan();
        SelisihBilangan sb = new SelisihBilangan();

        jb.tampilHasilJumlah();
        sb.tampilHasilSelisih();
    }
    
}
