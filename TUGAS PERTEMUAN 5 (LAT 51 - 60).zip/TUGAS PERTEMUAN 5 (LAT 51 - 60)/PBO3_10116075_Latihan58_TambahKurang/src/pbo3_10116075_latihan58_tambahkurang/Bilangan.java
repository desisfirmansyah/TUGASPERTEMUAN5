/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3_10116075_latihan58_tambahkurang;

/**
 *
*  Nama : DESIS FIRMANSYAH
* Kelas : IF3
* NIM   : 10116075
* Deskripsi Program : program ini berisi program untuk menampilkan hasil 
* penjumlahan dan hasil selisih dengan inputan yg sudah ditentukan dengan konsep
* inheritance
 */
public class Bilangan {
    private int x;
    private int y;

    public Bilangan() {
        this.x = 3;
        this.y = 5;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
   
}
