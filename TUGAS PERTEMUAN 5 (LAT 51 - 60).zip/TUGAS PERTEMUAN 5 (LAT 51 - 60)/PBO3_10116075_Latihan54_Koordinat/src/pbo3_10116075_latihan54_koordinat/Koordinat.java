/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3_10116075_latihan54_koordinat;

/**
 *
 *  Nama : DESIS FIRMANSYAH
* Kelas : IF3
* NIM   : 10116075
* Deskripsi Program : program ini berisi program untuk menampilkan koordinat
* berdasarkan warna dengan konsep inheritance
 */
public class Koordinat {
    protected int x;
    protected int y;
    
  public Koordinat(int x, int y){
       setX(x);
        setY(y);
  }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    
}
